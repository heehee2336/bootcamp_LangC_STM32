/*
 * counter.c
 *
 *  Created on: 2026. 11. 3.
 *      Author: kccistc
 */

#include "counter.h"
#include "../../../driver/joyStick/joyStick.h"
#include "../../../driver/lcd/lcd.h"
#include <stdio.h>

#define POS		1
#define NEG		0

extern I2C_HandleTypeDef hi2c1;




cordinate_XY cord_value;

count_XY countData;

typedef struct {
	uint16_t x_abs;
	uint8_t x_sign;
	uint16_t y_abs;
	uint8_t y_sign;
} cordData_t;

cordData_t cordData;

static upmode_state state = NORMAL;

char str[30];
char sign[10];

void count_init(void)
{
	js_init();
	Lcd_init(&hi2c1);
	cordData.x_abs = 0;
	cordData.x_sign = 0;
	cordData.y_abs = 0;
	cordData.y_sign = 0;
	countData.count_X = 950;
	countData.count_Y = -950;
}



void count_getCordData(void) {
	js_getValue(&cord_value);
	cordData.x_abs = (cord_value.X_cord > 50) ? cord_value.X_cord - 50 : 50 - cord_value.X_cord;
	cordData.x_sign = (cord_value.X_cord > 50) ? POS : NEG;
	cordData.y_abs = (cord_value.Y_cord > 50) ? cord_value.Y_cord - 50 : 50 - cord_value.Y_cord;
	cordData.y_sign = (cord_value.Y_cord > 50) ? POS : NEG;
}





void count_task(void)
{
	switch(state)
	{
	case X_MODE:
		if (cordData.x_sign == POS) {
			countData.count_X ++;
			if (countData.count_X == 1000)
			{
				countData.count_X = -999;
			}
		} else {
			countData.count_X --;
			if (countData.count_X == -1000)
			{
				countData.count_X = 999;
			}
		}
		state = NORMAL;
		HAL_Delay((60 - cordData.x_abs)*10);
		break;
	case Y_MODE:
		if (cordData.y_sign == POS) {
			countData.count_Y ++;
			if (countData.count_Y == 1000)
			{
				countData.count_Y = -999;
			}
		} else {
			countData.count_Y --;
			if (countData.count_Y == -1000)
			{
				countData.count_Y = 999;
			}
		}
		state = NORMAL;
		HAL_Delay((60 - cordData.y_abs)*10);
		break;
	case NORMAL:
		count_getCordData();
		if((cordData.x_abs > cordData.y_abs) && (cordData.x_abs > 10)) {
			state  = X_MODE;
		}
		else if ((cordData.x_abs <= cordData.y_abs) && (cordData.y_abs > 10)) {
			state  = Y_MODE;
		}

		sprintf(str,"X : %03d              ", countData.count_X);
		Lcd_writeStringXY(0, 0, str);

		sprintf(str,"Y : %03d             ", countData.count_Y);
		Lcd_writeStringXY(1, 0, str);
		break;
	default :
		break;
	}

}
