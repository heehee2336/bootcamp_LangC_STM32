/*
 * elevator.c
 *
 *  Created on: 2026. 11. 5.
 *      Author: kccistc
 */


#include "elevator.h"
#include "../../../driver/button/button.h"
#include "../elevatorMoving/elevatorMoving.h"
#include <stdbool.h>

#define FLOOR_1		0
#define FLOOR_2		1
#define FLOOR_3		2

uint16_t current_floor = FLOOR_1;
uint16_t target_floor  = FLOOR_1;

button_t btn_floor_1;
button_t btn_floor_2;
button_t btn_floor_3;

bool is_target_floor_arrive[3] = {false};

elevator_state_t elevator_state = IDLE;

static void is_target_floor_Clear(void);
static void Elevator_setTargetFloor();

void Elevator_init(void){

	button_init(&btn_floor_1,GPIOC,GPIO_PIN_3);
	button_init(&btn_floor_2,GPIOC,GPIO_PIN_1);
	button_init(&btn_floor_3,GPIOC,GPIO_PIN_0);
}

static void Elevator_setTargetFloor() {


	target_floor = current_floor;

	if (button_getState(&btn_floor_1) == ACT_RELEASE) {
		target_floor = FLOOR_1;
	}
	else if(button_getState(&btn_floor_2) == ACT_RELEASE){
		target_floor = FLOOR_2;
	}
	else if(button_getState(&btn_floor_3) == ACT_RELEASE){
		target_floor = FLOOR_3;
	}

	if (current_floor < target_floor)
	{
		elevator_state = RISING;
	}
	else if (current_floor < target_floor)
	{
		elevator_state = FALLING;
	}
}

void Elevator_ISR(uint16_t floor)
{
	is_target_floor_arrive[floor] = true;
}

static void is_target_floor_Clear(void)
{
	is_target_floor_arrive[0] = false;
	is_target_floor_arrive[1] = false;
	is_target_floor_arrive[2] = false;
}

void Elevator_task(void)
{
	switch(elevator_state){
	case IDLE :
		Elevator_setTargetFloor(&current_floor);
		elevatorMoving_Stop();
		break;
	case RISING :
		elevatorMoving_setDirCW();
		elevatorMoving_Run();
		if (is_target_floor_arrive[target_floor] == true) {
			current_floor = target_floor;
			elevator_state = ARRIVE;
		}
		else elevator_state = RISING;
		break;
	case FALLING :
		elevatorMoving_setDirCCW();
		elevatorMoving_Run();
		if (is_target_floor_arrive[target_floor] == true) {
			current_floor = target_floor;
			elevator_state = ARRIVE;
		}
		else elevator_state = FALLING;
		break;
	case ARRIVE :
		is_target_floor_Clear();
		elevator_state = IDLE;
		break;
	default :
		elevator_state = IDLE;
		break;
	}

}
